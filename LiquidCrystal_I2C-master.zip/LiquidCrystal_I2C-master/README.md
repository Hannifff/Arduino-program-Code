# LiquidCrystal_I2C

LiquidCrystal Arduino library for I2C LCD displays

**Status: Archived** 
This repository has been transfered to GitLab at https://gitlab.com/tandembyte/LCD_I2C
